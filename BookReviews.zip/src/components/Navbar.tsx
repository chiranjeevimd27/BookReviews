import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, User } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function Navbar() {
  const [user, setUser] = React.useState(supabase.auth.getUser());

  React.useEffect(() => {
    supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user || null);
    });
  }, []);

  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <BookOpen className="h-6 w-6 text-indigo-600" />
            <span className="text-xl font-bold text-gray-900">BookReviews</span>
          </Link>

          <div className="flex items-center space-x-4">
            <Link to="/books" className="text-gray-700 hover:text-indigo-600">
              Books
            </Link>
            {user ? (
              <Link to="/profile" className="flex items-center space-x-1 text-gray-700 hover:text-indigo-600">
                <User className="h-5 w-5" />
                <span>Profile</span>
              </Link>
            ) : (
              <Link to="/auth" className="text-indigo-600 hover:text-indigo-700 font-medium">
                Sign In
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}