import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Book, Review } from '../types/database';
import { supabase } from '../lib/supabase';
import { Star } from 'lucide-react';

export default function BookDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = React.useState<Book | null>(null);
  const [reviews, setReviews] = React.useState<Review[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [user, setUser] = React.useState<any>(null);
  const [newReview, setNewReview] = React.useState({ rating: 5, content: '' });
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => setUser(user));
  }, []);

  React.useEffect(() => {
    async function fetchBookAndReviews() {
      try {
        const [bookResponse, reviewsResponse] = await Promise.all([
          supabase
            .from('books')
            .select('*')
            .eq('id', id)
            .single(),
          supabase
            .from('reviews')
            .select(`
              *,
              profiles (
                username,
                avatar_url
              )
            `)
            .eq('book_id', id)
            .order('created_at', { ascending: false })
        ]);

        if (bookResponse.error) throw bookResponse.error;
        if (reviewsResponse.error) throw reviewsResponse.error;

        setBook(bookResponse.data);
        setReviews(reviewsResponse.data || []);
      } catch (error) {
        console.error('Error fetching book details:', error);
        setError('Failed to load book details. Please try again later.');
      } finally {
        setLoading(false);
      }
    }

    if (id) {
      fetchBookAndReviews();
    }
  }, [id]);

  async function handleReviewSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) {
      navigate('/auth');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const { error } = await supabase
        .from('reviews')
        .insert([
          {
            book_id: id,
            user_id: user.id,
            rating: newReview.rating,
            content: newReview.content,
          },
        ]);

      if (error) throw error;

      // Fetch updated reviews
      const { data: newReviews, error: fetchError } = await supabase
        .from('reviews')
        .select(`
          *,
          profiles (
            username,
            avatar_url
          )
        `)
        .eq('book_id', id)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      setReviews(newReviews || []);
      setNewReview({ rating: 5, content: '' });
    } catch (error) {
      setError(error.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  if (error) {
    return <div className="text-center py-8 text-red-600">{error}</div>;
  }

  if (!book) {
    return <div className="text-center py-8">Book not found</div>;
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="md:flex">
          {book.cover_url && (
            <div className="md:w-1/3">
              <img
                src={book.cover_url}
                alt={book.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}
          <div className="p-6 md:w-2/3">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{book.title}</h1>
            <p className="text-xl text-gray-600 mb-4">{book.author}</p>
            {book.description && (
              <p className="text-gray-700 mb-4">{book.description}</p>
            )}
            {book.isbn && (
              <p className="text-sm text-gray-500">ISBN: {book.isbn}</p>
            )}
          </div>
        </div>
      </div>

      {user && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">Write a Review</h3>
          <form onSubmit={handleReviewSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Rating
              </label>
              <div className="flex space-x-2">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    type="button"
                    onClick={() => setNewReview(prev => ({ ...prev, rating }))}
                    className={`p-1 ${newReview.rating >= rating ? 'text-yellow-400' : 'text-gray-300'}`}
                  >
                    <Star className="h-6 w-6 fill-current" />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Review
              </label>
              <textarea
                value={newReview.content}
                onChange={(e) => setNewReview(prev => ({ ...prev, content: e.target.value }))}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                rows={4}
                required
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50"
            >
              {submitting ? 'Submitting...' : 'Submit Review'}
            </button>
          </form>
        </div>
      )}

      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-gray-900">Reviews</h2>
        {reviews.length === 0 ? (
          <p className="text-gray-600">No reviews yet. Be the first to review!</p>
        ) : (
          reviews.map((review) => (
            <div key={review.id} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-4">
                {review.profiles?.avatar_url && (
                  <img
                    src={review.profiles.avatar_url}
                    alt={review.profiles.username}
                    className="w-10 h-10 rounded-full mr-4"
                  />
                )}
                <div>
                  <p className="font-semibold">{review.profiles?.username}</p>
                  <div className="flex items-center">
                    <div className="flex text-yellow-400">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                    </div>
                    <span className="text-gray-400 text-sm ml-2">
                      {new Date(review.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>
              <p className="text-gray-700">{review.content}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}