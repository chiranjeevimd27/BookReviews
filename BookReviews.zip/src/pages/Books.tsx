import React from 'react';
import { Link } from 'react-router-dom';
import { Book } from '../types/database';
import { supabase } from '../lib/supabase';

export default function Books() {
  const [books, setBooks] = React.useState<Book[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [searchQuery, setSearchQuery] = React.useState('');
  const [error, setError] = React.useState<string | null>(null);

  const fetchBooks = React.useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('books')
        .select('*')
        .order('title');

      if (fetchError) {
        console.error('Supabase error:', fetchError);
        throw new Error('Failed to fetch books');
      }

      if (!data || data.length === 0) {
        const sampleBooks = [
          {
            title: 'The Great Gatsby',
            author: 'F. Scott Fitzgerald',
            description: 'A story of decadence and excess.',
            cover_url: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=2487&ixlib=rb-4.0.3',
            featured: true
          },
          {
            title: '1984',
            author: 'George Orwell',
            description: 'A dystopian social science fiction novel.',
            cover_url: 'https://images.unsplash.com/photo-1506880018603-83d5b814b5a6?auto=format&fit=crop&q=80&w=2487&ixlib=rb-4.0.3',
            featured: true
          },
          {
            title: 'To Kill a Mockingbird',
            author: 'Harper Lee',
            description: 'A story of racial injustice and loss of innocence.',
            cover_url: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=2487&ixlib=rb-4.0.3',
            featured: true
          }
        ];

        const { error: insertError } = await supabase
          .from('books')
          .insert(sampleBooks);

        if (insertError) {
          console.error('Insert error:', insertError);
          throw new Error('Failed to create sample books');
        }

        // Fetch the newly inserted books
        const { data: newData, error: refetchError } = await supabase
          .from('books')
          .select('*')
          .order('title');

        if (refetchError) {
          console.error('Refetch error:', refetchError);
          throw new Error('Failed to fetch new books');
        }

        setBooks(newData || []);
      } else {
        setBooks(data);
      }
    } catch (error) {
      console.error('Error in fetchBooks:', error);
      setError('Failed to load books. Please try again later.');
      setBooks([]);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchBooks();
  }, [fetchBooks]);

  const filteredBooks = React.useMemo(() => 
    books.filter(book => 
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase())
    ),
    [books, searchQuery]
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-gray-600">Loading books...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-red-600 text-center">
          <p className="text-lg font-semibold mb-2">Error</p>
          <p>{error}</p>
          <button 
            onClick={fetchBooks}
            className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Books</h1>
        <div className="w-64">
          <input
            type="search"
            placeholder="Search books..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            aria-label="Search books"
          />
        </div>
      </div>

      {filteredBooks.length === 0 ? (
        <div className="text-center py-8 text-gray-600">
          <p>No books found. {searchQuery && 'Try a different search term.'}</p>
          {books.length === 0 && !searchQuery && (
            <button
              onClick={fetchBooks}
              className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition"
            >
              Refresh Books
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredBooks.map((book) => (
            <Link
              key={book.id}
              to={`/books/${book.id}`}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition group"
            >
              {book.cover_url && (
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={book.cover_url}
                    alt={book.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
              )}
              <div className="p-4">
                <h2 className="font-semibold text-gray-900 mb-1 group-hover:text-indigo-600 transition-colors">
                  {book.title}
                </h2>
                <p className="text-gray-600">{book.author}</p>
                {book.description && (
                  <p className="text-gray-500 text-sm mt-2 line-clamp-2">
                    {book.description}
                  </p>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}