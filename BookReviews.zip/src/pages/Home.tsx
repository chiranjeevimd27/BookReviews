import React from 'react';
import { Link } from 'react-router-dom';
import { Book } from '../types/database';
import { supabase } from '../lib/supabase';

export default function Home() {
  const [featuredBooks, setFeaturedBooks] = React.useState<Book[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    async function fetchFeaturedBooks() {
      try {
        const { data, error } = await supabase
          .from('books')
          .select('*')
          .eq('featured', true)
          .limit(4);

        if (error) throw error;
        setFeaturedBooks(data || []);
      } catch (error) {
        console.error('Error fetching featured books:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchFeaturedBooks();
  }, []);

  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Discover Your Next Favorite Book
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Join our community of book lovers. Read reviews, share your thoughts, and explore new stories.
        </p>
        <Link
          to="/books"
          className="inline-block bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition"
        >
          Browse Books
        </Link>
      </section>

      <section>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Featured Books</h2>
        {loading ? (
          <div className="text-center">Loading...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredBooks.map((book) => (
              <Link
                key={book.id}
                to={`/books/${book.id}`}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition"
              >
                {book.cover_url && (
                  <img
                    src={book.cover_url}
                    alt={book.title}
                    className="w-full h-48 object-cover"
                  />
                )}
                <div className="p-4">
                  <h3 className="font-semibold text-gray-900">{book.title}</h3>
                  <p className="text-gray-600">{book.author}</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}